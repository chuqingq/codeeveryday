This is the list of non-anonymous GoSublime donors and supporters (the thought counts as well).
Its purpose is to thank the many supporters of myself and GoSublime, so thank you all! :)

(If you donated anonymously and would like to be added, or would otherwise liked your entry to be updated(or removed) please contact me)

* Alexey "AlekSi" Palazhchenko https://github.com/AlekSi
* AmandaC https://github.com/AmandaCameron
* Daniele Baroncelli http://www.baroncelli.eu
* E Brady https://github.com/ebrady
* Erik Unger https://github.com/ungerik
* Frank Schroeder https://go-left.com/
* Fredrik Ehnbom http://pledgie.com/accounts/quarnster
* guillermooo https://github.com/guillermooo
* Hans Stimer
* Joe Farro http://jf.io/
* Joe Poirier https://github.com/jpoirier
* Jérémy Ozog http://www.jeremy-ozog.fr
* Karl Tuhkanen
* Mark Smith http://qq.is
* Maxim Kouprianov https://github.com/Xlab
* Nathan Youngman http://nathany.com/
* Peter Olds https://github.com/polds
* ProGNOMmers https://github.com/ProGNOMmers
* Ralf Rottmann http://twitter.com/ralf
* Sander van Harmelen https://github.com/svanharmelen
* Tom Westberg
* Yves Junqueira http://pledgie.com/accounts/@cetico
