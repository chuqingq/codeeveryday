// +build go1.4

package main

const SrcPkg = "src"
