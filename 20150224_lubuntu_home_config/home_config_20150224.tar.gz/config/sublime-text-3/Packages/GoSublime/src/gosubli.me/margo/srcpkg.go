// +build !go1.4

package main

import (
	"path/filepath"
)

const SrcPkg = "src" + string(filepath.Separator) + "pkg"
